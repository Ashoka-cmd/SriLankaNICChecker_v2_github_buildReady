package lk.nicchecker

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

private data class NicResult(
    val dob: String,
    val gender: String,
    val format: String,
    val age: String
)

class MainActivity : Activity() {
    private lateinit var input: EditText
    private lateinit var resultBox: LinearLayout
    private lateinit var error: TextView
    private lateinit var decodeButton: Button
    private lateinit var clearButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(245, 248, 252))
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(28))
        }
        scroll.addView(content)

        val title = TextView(this).apply {
            text = "Sri Lanka NIC Checker"
            textSize = 27f
            setTextColor(Color.rgb(18, 78, 140))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        content.addView(title, lp(MATCH, dp(56)))

        val subtitle = TextView(this).apply {
            text = "ජාතික හැඳුනුම්පත් අංකයෙන් උපන් දිනය සහ ස්ත්‍රී / පුරුෂ භාවය හඳුනාගන්න"
            textSize = 15.5f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(75, 85, 99))
        }
        content.addView(subtitle, lp(MATCH, dp(62)))

        val inputLabel = TextView(this).apply {
            text = "NIC අංකය"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(40, 40, 40))
        }
        content.addView(inputLabel, lp(MATCH, dp(30)).also { it.topMargin = dp(12) })

        input = EditText(this).apply {
            hint = "උදා: 901234567V හෝ 199012345678"
            textSize = 19f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            filters = arrayOf(InputFilter.LengthFilter(14))
            setSingleLine(true)
            setPadding(dp(16), 0, dp(16), 0)
            setSelectAllOnFocus(false)
            setOnEditorActionListener { _, _, _ -> decode(); true }
        }
        content.addView(input, lp(MATCH, dp(58)).also { it.topMargin = dp(4) })

        val hint = TextView(this).apply {
            text = "ඉඩක් හෝ - ලකුණක් ඇතුළත් කළත් App එක එය ස්වයංක්‍රීයව ඉවත් කරයි."
            textSize = 12.5f
            setTextColor(Color.GRAY)
        }
        content.addView(hint, lp(MATCH, dp(38)).also { it.topMargin = dp(2) })

        decodeButton = Button(this).apply {
            text = "✓  පරීක්ෂා කර බලන්න"
            textSize = 16.5f
            isAllCaps = false
            setOnClickListener { decode() }
        }
        content.addView(decodeButton, lp(MATCH, dp(54)).also { it.topMargin = dp(8) })

        clearButton = Button(this).apply {
            text = "හිස් කරන්න"
            textSize = 15f
            isAllCaps = false
            setOnClickListener { clearAll() }
        }
        content.addView(clearButton, lp(MATCH, dp(48)).also { it.topMargin = dp(4) })

        error = TextView(this).apply {
            textSize = 14.5f
            setTextColor(Color.rgb(183, 28, 28))
            setPadding(dp(8), dp(10), dp(8), dp(4))
            visibility = View.GONE
        }
        content.addView(error, lp(MATCH, WRAP))

        resultBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        content.addView(resultBox, lp(MATCH, WRAP))

        val privacyCard = TextView(this).apply {
            text = "🔒  පෞද්ගලිකත්වය\nNIC අංකය Internet, Server හෝ Database වෙත යවන්නේ නැත. සියලු ගණනය කිරීම් මෙම දුරකථනය තුළම සිදු වේ."
            textSize = 13f
            setTextColor(Color.rgb(75, 75, 75))
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(Color.rgb(235, 241, 248))
        }
        content.addView(privacyCard, lp(MATCH, WRAP).also { it.topMargin = dp(18) })

        val note = TextView(this).apply {
            text = "සටහන: මෙය NIC අංකයේ ආකෘතිය සහ එහි encoded තොරතුරු පරීක්ෂා කරයි. NIC එක රජයෙන් නිකුත් කළ සැබෑ ලේඛනයක්දැයි offline ලෙස තහවුරු නොකරයි."
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(dp(4), dp(12), dp(4), 0)
        }
        content.addView(note, lp(MATCH, WRAP))

        setContentView(scroll)
    }

    private fun decode() {
        hideError()
        resultBox.removeAllViews()

        val raw = input.text.toString()
            .trim()
            .replace(" ", "")
            .replace("-", "")
            .uppercase(Locale.US)

        input.setText(raw)
        input.setSelection(input.length())

        if (raw.isEmpty()) {
            showError("කරුණාකර NIC අංකයක් ඇතුළත් කරන්න.")
            return
        }

        val result = when {
            raw.matches(Regex("\\d{9}[VX]")) -> decodeOld(raw)
            raw.matches(Regex("\\d{12}")) -> decodeNew(raw)
            else -> {
                showError("NIC අංකය නිවැරදි ආකෘතියක නොවේ. පැරණි ආකෘතිය: අංක 9 + V/X. නව ආකෘතිය: අංක 12.")
                null
            }
        }
        result?.let { showResult(it) }
    }

    private fun decodeOld(s: String): NicResult? {
        val yy = s.substring(0, 2).toInt()
        val year = 1900 + yy
        val encodedDay = s.substring(2, 5).toInt()
        return decodeDay(year, encodedDay, "පැරණි NIC ආකෘතිය")
    }

    private fun decodeNew(s: String): NicResult? {
        val year = s.substring(0, 4).toInt()
        val encodedDay = s.substring(4, 7).toInt()
        val currentYear = Calendar.getInstance().get(Calendar.YEAR)

        if (year !in 1900..currentYear) {
            showError("NIC අංකයේ උපන් වර්ෂය වලංගු පරාසයක නොවේ.")
            return null
        }
        return decodeDay(year, encodedDay, "නව NIC ආකෘතිය")
    }

    private fun decodeDay(year: Int, encodedDay: Int, format: String): NicResult? {
        if (encodedDay !in 1..866) {
            showError("NIC අංකයේ දිනයට අදාළ කොටස 001–866 අතර විය යුතුය.")
            return null
        }

        val female = encodedDay >= 501
        val dayOfYear = if (female) encodedDay - 500 else encodedDay
        val maxDay = if (isLeapYear(year)) 366 else 365

        if (dayOfYear !in 1..maxDay) {
            showError("NIC අංකයේ දිනයට අදාළ කොටස එම වර්ෂයට වලංගු නොවේ.")
            return null
        }

        val date = Calendar.getInstance().apply {
            clear()
            setLenient(false)
            set(Calendar.YEAR, year)
            set(Calendar.DAY_OF_YEAR, dayOfYear)
            try {
                timeInMillis
            } catch (_: IllegalArgumentException) {
                showError("NIC අංකයේ උපන් දිනය වලංගු නොවේ.")
                return null
            }
        }

        val now = Calendar.getInstance()
        if (date.after(now)) {
            showError("NIC අංකයෙන් ලැබෙන උපන් දිනය අනාගත දිනයක් විය නොහැක.")
            return null
        }

        val dob = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(date.time)
        var age = now.get(Calendar.YEAR) - year
        if (now.get(Calendar.DAY_OF_YEAR) < date.get(Calendar.DAY_OF_YEAR) && age > 0) age--

        return NicResult(
            dob = dob,
            gender = if (female) "ස්ත්‍රී" else "පුරුෂ",
            format = format,
            age = "$age වසර"
        )
    }

    private fun isLeapYear(year: Int): Boolean =
        year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)

    private fun showResult(r: NicResult) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(14))
            setBackgroundColor(Color.WHITE)
        }

        val heading = TextView(this).apply {
            text = "✓  NIC තොරතුරු"
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(27, 94, 32))
            setPadding(0, 0, 0, dp(8))
        }
        card.addView(heading)
        addRow(card, "උපන් දිනය", r.dob)
        addRow(card, "ස්ත්‍රී / පුරුෂ භාවය", r.gender)
        addRow(card, "වයස", r.age)
        addRow(card, "NIC ආකෘතිය", r.format)

        val copy = Button(this).apply {
            text = "ප්‍රතිඵල Copy කරන්න"
            textSize = 14f
            isAllCaps = false
            setOnClickListener { copyResult(r) }
        }
        card.addView(copy, lp(MATCH, dp(46)).also { it.topMargin = dp(8) })

        resultBox.addView(card, lp(MATCH, WRAP).also { it.topMargin = dp(14) })
    }

    private fun addRow(parent: LinearLayout, label: String, value: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(7), 0, dp(7))
        }
        val labelView = TextView(this).apply {
            text = label
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(55, 55, 55))
        }
        val valueView = TextView(this).apply {
            text = value
            textSize = 18f
            setTextColor(Color.rgb(20, 20, 20))
            gravity = Gravity.END
        }
        row.addView(labelView, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(valueView, LinearLayout.LayoutParams(0, WRAP, 1f))
        parent.addView(row)
    }

    private fun copyResult(r: NicResult) {
        val text = "Sri Lanka NIC Checker\nඋපන් දිනය: ${r.dob}\nස්ත්‍රී / පුරුෂ භාවය: ${r.gender}\nවයස: ${r.age}\nNIC ආකෘතිය: ${r.format}"
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("NIC Result", text))
        Toast.makeText(this, "ප්‍රතිඵලය Copy කළා.", Toast.LENGTH_SHORT).show()
    }

    private fun clearAll() {
        input.text.clear()
        hideError()
        resultBox.removeAllViews()
        input.requestFocus()
    }

    private fun showError(message: String) {
        error.text = "⚠  $message"
        error.visibility = View.VISIBLE
    }

    private fun hideError() {
        error.text = ""
        error.visibility = View.GONE
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)

    companion object {
        const val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
        const val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT
    }
}
