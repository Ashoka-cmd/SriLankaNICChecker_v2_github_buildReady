plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android { namespace = "lk.nicchecker"; compileSdk = 35
    defaultConfig { applicationId = "lk.nicchecker"; minSdk = 23; targetSdk = 35; versionCode = 2; versionName = "2.0" }
}
