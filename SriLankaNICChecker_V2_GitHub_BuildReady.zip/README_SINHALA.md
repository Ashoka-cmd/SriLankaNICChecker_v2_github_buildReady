# Sri Lanka NIC Checker — Version 2.0

ශ්‍රී ලංකා ජාතික හැඳුනුම්පත් අංකයෙන් උපන් දිනය, ස්ත්‍රී/පුරුෂ භාවය සහ වයස පෙන්වන Android App එකකි.

## සහාය දක්වන NIC ආකෘති
- පැරණි: අංක 9 + `V` හෝ `X`
- නව: අංක 12

## Version 2.0 වෙනස්කම්
- Leap year / non-leap year සඳහා day-of-year conversion නිවැරදි කර ඇත.
- එම වර්ෂයට වලංගු නොවන 366 වන දිනය non-leap year එකකදී ප්‍රතික්ෂේප කරයි.
- කාන්තා NIC day value (501–866) නිවැරදිව decode කරයි.
- අනාගත උපන් දිනය ප්‍රතික්ෂේප කරයි.
- Sinhala user interface වැඩිදියුණු කර ඇත.
- NIC input එකේ spaces සහ hyphens ස්වයංක්‍රීයව ඉවත් කරයි.
- ප්‍රතිඵල Copy button එකක් ඇත.
- Clear button එකෙන් නැවත පරීක්ෂා කළ හැක.
- Internet permission එකක් නැත; NIC දත්ත device එකෙන් පිටතට යවන්නේ නැත.

## Build කිරීම
Android Studio තුළ `SriLankaNICChecker` folder එක Open කර Gradle Sync කිරීමෙන් පසු **Build > Build APK(s)** තෝරන්න.

APK එක සාමාන්‍යයෙන් `app/build/outputs/apk/debug/app-debug.apk` යටතේ ලැබේ.

## වැදගත් සීමාව
මෙය NIC අංකයේ encoded තොරතුරු සහ ආකෘතිය decode/validate කරයි. NIC එක සැබෑ ලෙස රජයෙන් නිකුත් කළ ලේඛනයක්දැයි offline ලෙස තහවුරු නොකරයි.
